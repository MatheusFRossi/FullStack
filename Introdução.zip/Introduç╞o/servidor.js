var http = require('http');

var express = require('express');

var app = express();

app.use(express.static('./public'));

var server = http.createServer(app);

server.listen(80);

console.log('Servidor rodando...');

let bodyParser = require("body-parser")
app.use(bodyParser.urlencoded({extended: false }))
app.use(bodyParser.json())

app.get('/login', function(requisicao, resposta) {
    resposta.sendFile(__dirname + '/public/login.html');
});


let usuariosCadastrados = [];

app.post('/cadastrar', function(requisicao, resposta){
    let nome = requisicao.body.nome;
    let email = requisicao.body.email;
    let senha = requisicao.body.senha;
    let nascimento = requisicao.body.nascimento;

    usuariosCadastrados.push({
        nome: nome,
        email: email,
        senha: senha,
        nascimento: nascimento
    });

    console.log("Usuários cadastrados:", usuariosCadastrados);

    resposta.render('resposta.ejs', { mensagem: "usuário cadastrado com sucesso!", usuario: nome, email: email });
});

app.post('/login', function(requisicao, resposta) {
    let email = requisicao.body.email;
    let senha = requisicao.body.senha;

    let usuarioEncontrado = usuariosCadastrados.find(u => u.email === email && u.senha === senha);

    if (usuarioEncontrado) {
        resposta.render('resposta.ejs', {
            mensagem: "Login realizado com sucesso!",
            usuario: usuarioEncontrado.nome,
            email: usuarioEncontrado.email
        });
    } else {
        resposta.send('<script>alert("Usuário ou senha incorretos!"); window.location="/login";</script>');
    }
});
