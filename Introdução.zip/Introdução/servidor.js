var http = require('http');

var express = require('express');

var app = express();

app.use(express.static('./public'));

var server = http.createServer(app);

server.listen(80);

console.log('Servidor rodando...');

let bodyParser = require("body-parser")
app.use(bodyParser.urlencoded({extended: false }))
app.use(bodyParser.json())

app.get("/inicio", function(requisicao, resposta){
    resposta.redirect('aula_10/index2.html');
})
app.post("/inicio", function(requisicao, resposta){
    resposta.redirect('aula_10/index2.html');
})
app.get('/cadastrar', function(requisicao, resposta){
    let nome = requisicao.query.nome;
    let email = requisicao.query.email;
    let senha = requisicao.query.senha;
    let nascimento = requisicao.query.nascimento;

    console.log(nome, email, senha, nascimento);
    resposta.render('resposta.ejs', {mensagem: "usuario cadastrado com sucesso!", usuario: nome, email: email});
})
app.post('/cadastrar', function(requisicao, resposta){
    let nome = requisicao.body.nome;
    let email = requisicao.body.email;
    let senha = requisicao.body.senha;
    let nascimento = requisicao.body.nascimento;

    console.log(nome, email, senha, nascimento);
    resposta.render('resposta.ejs', {mensagem: "usuario cadastrado com sucesso!", usuario: nome, email: email});
})