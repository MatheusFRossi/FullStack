var http = require('http');

var express = require('express');

var app = express();

app.use(express.static('./public'));

var server = http.createServer(app);

var mongodb = require("mongodb");

const MongoClient = mongodb.MongoClient;

const uri = 'mongodb+srv://matheus:9hWyBx50WWIgkQHL@fullstack.amq3flx.mongodb.net/?retryWrites=true&w=majority&appName=FullStack';

const client = new MongoClient(uri, { useNewUrlParser: true });

var dbo = client.db("CRUD_bd");
var usuarios = dbo.collection("usuarios");

server.listen(3000);

console.log('Servidor rodando...');

let bodyParser = require("body-parser")
app.use(bodyParser.urlencoded({extended: false }))
app.use(bodyParser.json())

app.post("/cadastrar_usuario", function(req, resp) {
    var data = { db_nome: req.body.nome, db_login: req.body.login, db_senha: req.body.senha };

    usuarios.insertOne(data, function (err) {
      console.log(err)
      if (err) {
        resp.render('resposta_usuario.ejs', {resposta: "Erro ao cadastrar usuário!"})
      }else {
        resp.render('resposta_usuario.ejs', {resposta: "Usuário cadastrado com sucesso!"})        
      };
    });
   
  });


  app.post("/logar_usuario", function(req, resp) {
    var data = {db_login: req.body.login, db_senha: req.body.senha };

    console.log(data)
    usuarios.find(data).toArray(function(err, items) {
      console.log(items);
      if (items.length == 0) {
        resp.render('resposta_usuario.ejs', {resposta: "Usuário/senha não encontrado!"})
      }else if (err) {
        resp.render('resposta_usuario.ejs', {resposta: "Erro ao logar usuário!"})
      }else {
        resp.render('resposta_usuario.ejs', {resposta: "Usuário logado com sucesso!"})        
      };
    });

  });

  app.post("/atualizar_usuario", function(req, resp) {
    var data = { db_login: req.body.login, db_senha: req.body.senha };
    var newData = { $set: {db_senha: req.body.novasenha} };

    usuarios.updateOne(data, newData, function (err, result) {
      console.log(result);
      if (result.modifiedCount == 0) {
        resp.render('resposta_usuario', {resposta: "Usuário/senha não encontrado!"})
      }else if (err) {
        resp.render('resposta_usuario', {resposta: "Erro ao atualizar usuário!"})
      }else {
        resp.render('resposta_usuario', {resposta: "Usuário atualizado com sucesso!"})        
      };
    });
   
  });

  app.post("/remover_usuario", function(req, resp) {
    var data = { db_login: req.body.login, db_senha: req.body.senha };
   
    usuarios.deleteOne(data, function (err, result) {
      console.log(result);
      if (result.deletedCount == 0) {
        resp.render('resposta_usuario', {resposta: "Usuário/senha não encontrado!"})
      }else if (err) {
        resp.render('resposta_usuario', {resposta: "Erro ao remover usuário!"})
      }else {
        resp.render('resposta_usuario', {resposta: "Usuário removido com sucesso!"})        
      };
    });

  });




app.get('/login', function(requisicao, resposta) {
    resposta.sendFile(__dirname + '/public/login.html');
});


let usuariosCadastrados = [];

app.post('/cadastrar', function(requisicao, resposta){
    let nome = requisicao.body.nome;
    let email = requisicao.body.email;
    let senha = requisicao.body.senha;
    let nascimento = requisicao.body.nascimento;

    usuariosCadastrados.push({
        nome: nome,
        email: email,
        senha: senha,
        nascimento: nascimento
    });

    console.log("Usuários cadastrados:", usuariosCadastrados);

    resposta.render('resposta.ejs', { mensagem: "usuário cadastrado com sucesso!", usuario: nome, email: email });
});

app.post('/login', function(requisicao, resposta) {
    let email = requisicao.body.email;
    let senha = requisicao.body.senha;

    let usuarioEncontrado = usuariosCadastrados.find(u => u.email === email && u.senha === senha);

    if (usuarioEncontrado) {
        resposta.render('resposta.ejs', {
            mensagem: "Login realizado com sucesso!",
            usuario: usuarioEncontrado.nome,
            email: usuarioEncontrado.email
        });
    } else {
        resposta.send('<script>alert("Usuário ou senha incorretos!"); window.location="/login";</script>');
    }
});
